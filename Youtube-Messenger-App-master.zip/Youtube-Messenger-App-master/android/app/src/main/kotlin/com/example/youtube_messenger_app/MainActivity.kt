package com.example.youtube_messenger_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
